package com.cg.project.exception;

@SuppressWarnings("serial")
public class CRSException extends Exception {
	public CRSException(String message) {
		super(message);
	}
}
